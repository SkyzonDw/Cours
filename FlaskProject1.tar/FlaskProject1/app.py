from flask import Flask, request, render_template, redirect, url_for, abort, flash

app = Flask(__name__)
app.config["TEMPLATES_AUTO_RELOAD"] = True
app.secret_key = 'une cle(token) : grain de sel(any random string)'

typesMeuble = [
    {'id': 1, 'libelle': 'canape'},
    {'id': 2, 'libelle': 'lit'},
    {'id': 3, 'libelle': 'commode'},
    {'id': 4, 'libelle': 'armoire'},
]

meubles = [
    {'id': 1, 'nomMeuble': 'klippan', 'prixMeuble': '50.20', 'dateFabrication': '2020-06-06', 'couleur': 'rouge',
     'materiaux': 'bois', 'typeMeuble_id': 1, 'nbStock': '3', 'image': 'klippan.png'},
    {'id': 2, 'nomMeuble': 'malm', 'prixMeuble': '12.00', 'dateFabrication': '2020-06-06', 'couleur': 'vert',
     'materiaux': 'acier', 'typeMeuble_id': 2, 'nbStock': '5', 'image': 'malm.png'},
    {'id': 3, 'nomMeuble': 'besta', 'prixMeuble': '14.36', 'dateFabrication': '2020-06-06', 'couleur': 'jaune',
     'materiaux': 'bois', 'typeMeuble_id': 3, 'nbStock': '6', 'image': 'besta.jpg'},
    {'id': 4, 'nomMeuble': 'billy', 'prixMeuble': '24.59', 'dateFabrication': '2020-06-06', 'couleur': 'bleu',
     'materiaux': 'verre', 'typeMeuble_id': 4, 'nbStock': '2', 'image': 'billy.jpg'},
    {'id': 5, 'nomMeuble': 'friheten', 'prixMeuble': '42.21', 'dateFabrication': '2020-06-06', 'couleur': 'ebene',
     'materiaux': 'acier', 'typeMeuble_id': 1, 'nbStock': '8', 'image': 'friheten.png'},
    {'id': 6, 'nomMeuble': 'brimnes', 'prixMeuble': '11.11', 'dateFabrication': '2019-06-06', 'couleur': 'magenta',
     'materiaux': 'alumonium', 'typeMeuble_id': 2, 'nbStock': '5', 'image': 'brimnes.png'},
    {'id': 7, 'nomMeuble': 'la commode du luxe', 'prixMeuble': '35.21', 'dateFabrication': '2019-06-06',
     'couleur': 'voilet', 'materiaux': 'marbre', 'typeMeuble_id': 3, 'nbStock': '1', 'image': 'commodeLuxe.jpg'},
    {'id': 8, 'nomMeuble': 'lack', 'prixMeuble': '32.25', 'dateFabrication': '2019-12-06', 'couleur': 'gris',
     'materiaux': 'acier', 'typeMeuble_id': 4, 'nbStock': '7', 'image': 'lack.png'},
    {'id': 9, 'nomMeuble': 'vilme', 'prixMeuble': '52.36', 'dateFabrication': '2019-12-26', 'couleur': 'satin',
     'materiaux': 'bois', 'typeMeuble_id': 1, 'nbStock': '4', 'image': 'vilme.png'},
]

@app.route('/')
def show_accueil():
    return render_template('layout.html')

@app.route('/type-meuble/show')
def show_type_meuble():
    return render_template('type_meuble/show_type_meuble.html', typesMeuble=typesMeuble)

@app.route('/type-meuble/add', methods=['GET'])
def add_type_meuble():
    return render_template('type_meuble/add_type_meuble.html')

@app.route('/type-meuble/add', methods=['POST'])
def valid_add_type_meuble():
    libelle = request.form.get('libelle', '')
    if not libelle:
        flash('Le libellé est requis.', 'alert-danger')
        return redirect('/type-meuble/add')
    print(u'type ajouté , libellé :', libelle)
    message = u'type ajouté , libellé :' + libelle
    flash(message, 'alert-success')
    return redirect('/type-meuble/show')

@app.route('/type-meuble/delete', methods=['GET'])
def delete_type_meuble():
    id = request.args.get('id', '')
    if not id or not id.isdigit() or not any(type['id'] == int(id) for type in typesMeuble):
        flash('Erreur: type de meuble non trouvé pour la suppression.', 'alert-danger')
        return redirect('/type-meuble/show')
    print("un type de meuble supprimé, id :", id)
    message = u'un type de meuble supprimé, id : ' + id
    flash(message, 'alert-warning')
    return redirect('/type-meuble/show')

@app.route('/type-meuble/edit', methods=['GET'])
def edit_type_meuble():
    id = request.args.get('id', '')
    if not id or not id.isdigit():
        flash('ID non valide.', 'alert-danger')
        return redirect('/type-meuble/show')
    id = int(id)
    type_meuble = next((tm for tm in typesMeuble if tm['id'] == id), None)
    if type_meuble is None:
        flash('Type de meuble non trouvé', 'alert-danger')
        return redirect('/type-meuble/show')
    return render_template('type_meuble/edit_type_meuble.html', typeMeuble=type_meuble)

@app.route('/type-meuble/edit', methods=['POST'])
def valid_edit_type_meuble():
    libelle = request.form.get('libelle', '')
    id = request.form.get('id', '')
    if not libelle or not id:
        flash('Tous les champs sont requis.', 'alert-danger')
        return redirect(f'/type-meuble/edit?id={id}')
    print(u'type meuble modifié, id: ', id, " libelle :", libelle)
    message = u'type meuble modifié, id: ' + id + " libelle : " + libelle
    flash(message, 'alert-success')
    return redirect('/type-meuble/show')

@app.route('/meuble/show')
def show_meubles():
    return render_template('meuble/show_meuble.html', Meubles=meubles, typesMeuble=typesMeuble)

@app.route('/meuble/add', methods=['GET'])
def add_meuble():
    return render_template('meuble/add_meuble.html', typesMeuble=typesMeuble)

@app.route('/meuble/add', methods=['POST'])
def valid_add_meuble():
    nom = request.form.get('nom', '')
    type_meuble_id = request.form.get('type_meuble_id', '')
    prix = request.form.get('prix', '')
    stock = request.form.get('stock', '')
    description = request.form.get('description', '')
    image = request.form.get('image', '')
    if not nom or not type_meuble_id or not prix or not stock:
        flash('Tous les champs sont requis.', 'alert-danger')
        return redirect('/meuble/add')
    message = u'meuble ajouté , nom:' + nom + '---- type_meuble_id :' + type_meuble_id + ' ---- prix:' + prix + ' - stock:' + stock + ' - description:' + description + ' - image:' + image
    print(message)
    flash(message, 'alert-success')
    return redirect('/meuble/show')

@app.route('/meuble/delete', methods=['GET'])
def delete_meuble():
    id = request.args.get('id', '')
    if not id or not id.isdigit() or not any(meuble['id'] == int(id) for meuble in meubles):
        flash('Erreur: meuble non trouvé pour la suppression.', 'alert-danger')
        return redirect('/meuble/show')
    message = u'un meuble supprimé, id : ' + id
    flash(message, 'alert-warning')
    return redirect('/meuble/show')

@app.route('/meuble/edit', methods=['GET'])
def edit_meuble():
    id = request.args.get('id', '')
    if not id or not id.isdigit():
        flash('ID non valide.', 'alert-danger')
        return redirect('/meuble/show')
    id = int(id)
    meuble = next((m for m in meubles if m['id'] == id), None)
    if meuble is None:
        flash('Meuble non trouvé', 'alert-danger')
        return redirect('/meuble/show')
    return render_template('meuble/edit_meuble.html', meuble=meuble, typesMeuble=typesMeuble)

@app.route('/meuble/edit', methods=['POST'])
def valid_edit_meuble():
    id = request.form.get('id', '')
    nom = request.form.get('nom', '')
    type_meuble_id = request.form.get('type_meuble_id', '')
    prix = request.form.get('prix', '')
    stock = request.form.get('stock', '')
    description = request.form.get('description', '')
    image = request.form.get('image', '')
    if not id or not nom or not type_meuble_id or not prix or not stock:
        flash('Tous les champs sont requis.', 'alert-danger')
        return redirect(f'/meuble/edit?id={id}')
    message = u'meuble modifié , nom:' + nom + '---- type_meuble_id :' + type_meuble_id + ' ---- prix:' + prix + ' - stock:' + stock + ' - description:' + description + ' - image:' + image + u' ------ pour l meuble d identifiant :' + id
    print(message)
    flash(message, 'alert-success')
    return redirect('/meuble/show')

@app.route('/meubles')
def show_meuble_list():
    return render_template('meuble/show_meuble.html', Meubles=meubles)

@app.route('/meubles-filtre', methods=['GET', 'POST'])
def meubles_filtre():
    meubles = get_all_meubles()  # Récupérer tous les meubles
    typesMeuble = get_all_types()  # Récupérer tous les types de meubles

    if request.method == 'POST':
        selected_ids = request.form.getlist('type_meuble_ids')  # Obtenir les ids des types cochés
        prix_min = request.form.get('prix_min', '')  # Récupérer le prix minimum
        nom_recherche = request.form.get('nom_recherche', '')  # Récupérer le nom recherché

        # Validation simple
        if prix_min and not prix_min.isdigit():
            flash("Le prix minimum doit être un nombre.", 'alert-danger')
        else:
            flash(f"Types de meuble sélectionnés : {', '.join(selected_ids)}. Prix minimum : {prix_min}. Nom recherché : {nom_recherche}.", 'alert-success')

        return redirect('/meubles-filtre')

    return render_template('meuble/filtre.html', Meubles=meubles, typesMeuble=typesMeuble)


if __name__ == '__main__':
    app.run()